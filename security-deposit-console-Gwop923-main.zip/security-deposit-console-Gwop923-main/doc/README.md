# These files are for reference only

They contain the *initial values* of accounts in the database. Changes to account balances are *only* reflected in the database.

* `accounts.csv` - contains account usernames, account numbers, and starting balances
* `users.csv` - contains the account names and roles (CUSTOMER or BANKER), along with hashed password and salt.
